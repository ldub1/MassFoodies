# Individual assignment

## Setup & Installation

Make sure you have the latest version of Python installed.

```bash
git clone <repo-url>
```
#DEPENDENCES
flask
Flask-SQLAlchemy
flask-login

#NOTES
Was not able to show adding students to the same course
Foreign keys not implmemented
The packages above need to be installed in order for the project to work
To execute file run main.py
Multiple student can be created, they just can't have the same course name attached to them

## REFERENCES
#https://github.com/techwithtim/Flask-Web-App-Tutorial/tree/main/website

## Viewing The App

Go to `http://127.0.0.1:5000`
"# cmsc447-Project" 
